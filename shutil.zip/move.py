#www.yehia.online
import shutil                                                         
import time                                                           
from = raw_input(' Enter Path File')                                   
to = raw_input("  Enter Path Folder ")                                
print('Loading')                                                      
time.sleep(5)                                                         
shutil.move(from, to)                                                 
print('Done *_*')                                                     