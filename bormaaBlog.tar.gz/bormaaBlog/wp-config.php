<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */


// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'borma4blog' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'O)js|aQoNGEo+DoA%kmwdWH0GR*7oywz|Bbp_p84+MX+yDgZ]XP>!vU8?dTv[sZ:');
define('SECURE_AUTH_KEY',  '+|H=cmsxW--bV)|TnR)5OW`>C^/Cu.#q<aLwj`%@5b|t4:8>?k 8|#%_Br5V/1/y');
define('LOGGED_IN_KEY',    'of]!|fqc;j^W6-^Ii.|Un?6;5BtZ;z>RR(%u>q!pI-]NSsEUxwJ#n KSI+9aPi6e');
define('NONCE_KEY',        '}&:G))5^mI-xjd~#A(d9ms1>&j(>mIaN)wI}@#KZJ,Qb|-kDmB+/`b-1^?v{`?Le');
define('AUTH_SALT',        'tKP{<HwP#gp2}+,O-,lc.8xaPR.m Go/9;^.(7Z2gcsF+|F|g02JLZgB{@M9#|WM');
define('SECURE_AUTH_SALT', '^U,1*jy6UKfkU*0d{;oSnMcC;%0N/@[[vfdjJRBF7KBK-pV[H1K|+kwvB[`V+uQd');
define('LOGGED_IN_SALT',   '{z>o#}q46K!wPA&B%+QClXQy/1AZ?i)Q8h}M2<iI1 Ul=#-(^~!3^{5`O({OZpRe');
define('NONCE_SALT',       '3+T_$Rj%yA8Ijj~yco!>&I7i|iVKr@Mxg=O_0|FR5,Yvy_CzKdw` zbxFtBOT-|<');

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'br_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */

define('FS_METHOD','direct');



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}


function get_dynamic_home_url(){
    $base_dir  = ABSPATH; // Absolute path
    $doc_root  = preg_replace("!${_SERVER['SCRIPT_NAME']}$!", '', $_SERVER['SCRIPT_FILENAME']);
    $base_url  = preg_replace("!^${doc_root}!", '', $base_dir);
    $protocol  = empty($_SERVER['HTTPS']) ? 'http' : 'https';
    $port      = $_SERVER['SERVER_PORT'];
    $disp_port = ($protocol == 'http' && $port == 80 || $protocol == 'https' && $port == 443) ? '' : ":$port";
    $domain    = $_SERVER['HTTP_HOST'];
    $home_url  = "${protocol}://${domain}${disp_port}${base_url}";

    return $home_url;
}
$url = get_dynamic_home_url();
define('WP_SITEURL', $url);
define('WP_HOME', $url);



/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
