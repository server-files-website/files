#www.yehia.online
import shutil                                                         
import time                                                           
print("PLease Wait")                                                  
time.sleep(4)                                                         
shutil.copy("/fromfile","/tofolder")                                  
print('Done')                                                         